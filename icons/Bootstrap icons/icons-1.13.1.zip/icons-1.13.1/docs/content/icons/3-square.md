---
title: 3 square
categories:
  - Shapes
tags:
  - number
  - numeral
---
