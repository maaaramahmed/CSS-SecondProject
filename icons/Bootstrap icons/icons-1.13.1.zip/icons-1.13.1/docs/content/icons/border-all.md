---
title: Border all
categories:
  - UI and keyboard
tags:
  - borders
---
