---
title: Arrow up right square fill
categories:
  - Shape arrows
tags:
  - arrow
  - square
---
