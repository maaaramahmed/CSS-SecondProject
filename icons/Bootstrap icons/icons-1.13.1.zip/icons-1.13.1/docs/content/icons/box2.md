---
title: Box2
categories:
  - Real world
tags:
  - cardboard
  - package
  - cube
---
