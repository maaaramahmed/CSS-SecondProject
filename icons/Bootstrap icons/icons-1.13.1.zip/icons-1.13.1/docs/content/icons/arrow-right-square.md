---
title: Arrow right square
categories:
  - Shape arrows
tags:
  - arrow
  - square
---
