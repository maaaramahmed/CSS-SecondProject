---
title: Capsule pill
categories:
  - Medical
tags:
  - rx
  - pills
  - capsules
  - medicine
---
